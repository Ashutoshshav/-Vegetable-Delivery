import React from 'react';

function ButtomNav(props) {
    return (
        <div>
            
        </div>
    );
}

export default ButtomNav;