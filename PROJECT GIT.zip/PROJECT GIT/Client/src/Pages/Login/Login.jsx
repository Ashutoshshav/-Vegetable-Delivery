import React, { useState, useContext } from 'react';
import CustomerContext from '../../Contexts/CustomerContext/CustomerContext';
import axios from 'axios';

function Login(props) {
    const { setCustomer } = useContext(CustomerContext)
    const [errorMsg, setErrorMsg] = useState("");

    const [data, setData] = useState({
        email: "",
        password: ""
    })

    let handleChange = (e) => {
        const { name, value } = e.target;

        setData({
            ...data,
            [name]: value,
        })
    }

    let handleSubmit = (e) => {
        e.preventDefault()

        let response = axios.post("http://localhost:3000/api/user/login", data)
            .then((response) => {
                if (response.data.token == null) {
                    setErrorMsg(response.data)
                    console.log(response.data)
                } else {
                    localStorage.setItem("token", response.data.token);
                    setErrorMsg('Login Scccessfully')
                }
            })
    }
    return (
        <div className='flex items-center justify-center min-h-screen bg-gray-100'>
            <div className="bg-white shadow-lg rounded-lg p-8 max-w-sm w-full">
                <h1 className='text-2xl font-bold text-center text-gray-800 mb-6'>Login</h1>
                {errorMsg ? (<p className="text-center text-red-500 font-medium mb-4">{errorMsg}</p>) : ""}
                <form action="">
                    <div className='flex flex-col'>
                        <div className="mb-1">
                            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">Enter Email</label>
                            <input className="shadow appearance-none border rounded w-full py-2 px-1 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="email" id='email' placeholder='Enter Email' name='email' value={data.email} onChange={handleChange} />
                        </div>

                        <div className="mb-1">
                            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">Enter Password</label>
                            <input className="shadow appearance-none border rounded w-full py-2 px-1 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" id='password' placeholder='Enter Password' name='password' value={data.password} onChange={handleChange} />
                        </div>

                        <button className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline mt-2" onClick={handleSubmit}>Submit</button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default Login;