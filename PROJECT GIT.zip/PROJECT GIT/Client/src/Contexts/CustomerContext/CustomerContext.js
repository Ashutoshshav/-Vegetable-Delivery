import React from "react";

const CustomerContext = React.createContext()

export default CustomerContext;
