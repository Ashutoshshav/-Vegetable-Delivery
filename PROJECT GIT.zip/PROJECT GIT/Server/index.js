const express = require("express");
const sql = require('mssql');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
const path = require('path');
require('dotenv').config();
require('iisnode-env').config();


const config = require("./Utils/Connection")
const { handleVerifyUser } = require("./Middlewares/UserTokenVerify")

const productRoute = require("./Routes/ProductRoute")
const cartRoute = require("./Routes/CartRoute")
const orderRoute = require("./Routes/OrderRoute")
const userRoute = require("./Routes/UserRoute")

const port = process.env.PORT;

app.use(cors({
    origin: ["http://localhost:5173"],
    methods: ["*"],
    credentials: true
}));

app.use(bodyParser.json());

app.use(express.json());

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public', 'dist')));
// app.get('*', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'dist', 'index.html'));
// });

app.use("/", productRoute)
app.use("/api/user/", userRoute)
app.use("/api/cart/", handleVerifyUser, cartRoute)
app.use("/api/order/", handleVerifyUser, orderRoute)

// async function connection() {
//     try {
//         let pool = sql.connect(config).then(() => console.log("DB connected")).catch((e) => console.log(e))
//     } catch(e) {
//         console.log(e)
//     }
// }

// connection()

app.listen(port, (req, res) => {
    console.log("Server is running on " + port)
})
